<html>
	<head>
		<title>Customer Loyalty Research - Privacy Policy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="{{ asset('/css/bootstrap.min.css') }}" rel="stylesheet">
		
		<link href='http://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600' rel='stylesheet'>

		<style>
			body {
				padding-top: 20px;
			font-size: 16px;
			font-family: "Open Sans",serif;
			}

			.container {
				/*text-align: center;*/
				display: table-cell;
				vertical-align: middle;
				width: 80%;
				margin: 50px;
			}

			.content {
				/*text-align: center;*/
				/*display: inline-block;*/
			}

			.title {
				font-size: 40px;
				margin-bottom: 40px;
				text-align: center;
			}

			.quote {
				font-size: 24px;
			}
					.margin-base-vertical {
			margin: 40px 0;
		}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
				<div class="title"><img src="{{asset('/images/qut.png')}}" width="300px" class="pull-left" > Privacy Statement</div>
				<p class="">
					This study has been approved by the QUT Human Research Ethics Committee 
					(approval number xxxxxxxxx). QUT will not be able to personally identify you by 
					the information you provide in your responses to this survey, 
					unless you choose to provide your details and request us to contact you. 
					We will not disclose your personal information to third parties without 
					your consent, except in response to legal requirements. 
					QUT's privacy and security statement can be found at 
					<a href="https://www.qut.edu.au/additional/privacy">https://www.qut.edu.au/additional/privacy.</a>					
				</p>
				<p class="">
					By selecting the "I Consent" it is accepted as an indication of your consent 
					to participate in this project. By submitting your final answers and selecting 
					"Submit" at the end of the survey your completed online questionnaire will be accepted.
				</p>
				<p class="">
					It is expected that this project will not directly benefit you as it is 
					design to explore and explain intended customer behaviour where loyalty 
					programme membership does or does not exist in survey participants.
				</p>

				<p class="">
					QUT is committed to research integrity and the ethical conduct of research projects.  
					However, if you do have any concerns or complaints about the ethical conduct of the 
					project you may contact the QUT Research Ethics Unit on <strong>+61 7 3138 5123</strong> or 
					email <a href="mailto:ethicscontact@qut.edu.au">ethicscontact@qut.edu.au.</a>  
					The QUT Research Ethics Unit is not connected with the research project and 
					can facilitate a resolution to your concern in an impartial manner.
				</address>
				</p>
				</div>
			</div>
		</div>
	</body>
</html>
