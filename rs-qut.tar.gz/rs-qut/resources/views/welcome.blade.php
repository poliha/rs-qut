<html>
	<head>
		<title>Customer Loyalty Research</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="{{ asset('/css/bootstrap.min.css') }}" rel="stylesheet">
		
		<link href='http://fonts.googleapis.com/css?family=Abel|Open+Sans:400,600' rel='stylesheet'>

		<style>
			body {
				padding-top: 20px;
			font-size: 16px;
			font-family: "Open Sans",serif;
			}

			.container {
				/*text-align: center;*/
				display: table-cell;
				vertical-align: middle;
				width: 80%;
				margin: 50px;
			}

			.content {
				/*text-align: center;*/
				/*display: inline-block;*/
			}

			.title {
				font-size: 40px;
				margin-bottom: 40px;
				text-align: center;
			}

			.quote {
				font-size: 24px;
			}
					.margin-base-vertical {
			margin: 40px 0;
		}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
				<div class="title">Customer Loyalty Research</div>
				<p class="">
					As a panel member of My Opinions you have received this request to participate in an online survey. This survey is part of a market research project that is being undertaken as a component of my Master of Business Research degree at Queensland University of Technology (QUT). My topic focuses on how people use customer loyalty programmes and I am seeking people over the age of 18 years to complete the following online exercise and questionnaire. 
				</p>
				<p class="">
					Your participation in the online exercise will involve reading a scenario and then participating in a fictional shopping experience before, finally, answering a set of scaled-based questions (for example “on a scale of 1 – 7 date...”). In total, the exercise and questionnaire should take approximately 15 minutes. This study is completely voluntary and your answers will be anonymous. As the questionnaire is anonymous please bear in mind that once you submit your responses it will not be possible to withdraw them. Responses to all questions are required, however you can leave the survey at any time if you feel uncomfortable. If you leave the questionnaire and then restart it you will be taken back to the beginning.
				</p>
				<p class="">
					By selecting the "I Consent" button below it is accepted as an indication of your consent to participate in this project. By submitting your final answers and selecting “Submit” at the end of the survey your completed online questionnaire will be accepted.
 If you do not submit your survey then your answers will not be recorded.				</p>
				<p class="">
					Please click on "I consent" to commence the survey. I sincerely thank you for your involvement.
					</p><p>						
					<a href="{{url('home')}}" class="btn btn-success btn-lg"><i class="glyphicon glyphicon-ok"></i> I Consent</a>
				</p>
				<p class="">
					Should you have any questions please contact me via email 
					<a href="mailto:Rebecca.Sharpe@hdr.qut.edu.au ?subject=Customer Loyalty Research">Send Email</a> 
					<br>
					Alternatively you may wish to view the privacy policy at <a href="{{url('privacy')}}" target="_blank" >Privacy Policy Page</a>.
					<br>
					<address>
					Rebecca Sharpe, <br>
					Student QUT Graduate School of Business School
				</address>
				</p>
				</div>
			</div>
		</div>
	</body>
</html>
