<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Your Grocer</title>

	<link href="{{ asset('/css/app.css') }}" rel="stylesheet">
	<link href="{{ asset('/css/bootstrap-classic-plus-theme.css') }}" rel="stylesheet">

	<link href="{{ asset('/css/jquery.mCustomScrollbar.css') }}" rel="stylesheet">
	
	<!-- Fonts -->
	<link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>

	<link href="{{asset('/css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{ asset('/css/shop.css') }}" rel="stylesheet">
	<link href="{{asset('/css/flipclock.css')}}" rel="stylesheet">

		<!-- Scripts -->
	<script src="{{ asset('/js/jquery.min.js')}}"></script>
	<script src="{{ asset('/js/bootstrap.min.js')}}"></script>
	<script src="{{ asset('/js/flipclock.min.js')}}"></script>
<!--[if lt IE 7]>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->
    <!-- Fav and touch icons -->


<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js" type="text/javascript"></script>
    <![endif]-->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<style type="text/css">
		.make-blue{
			text-transform: uppercase;
			color: #3299dc;
			font-size: larger;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
		<div class="container">
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
			  <span class="sr-only">Toggle navigation</span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="{{ url('/') }}">YOUR GROCER</a>
		  </div>

		  <!-- Collect the nav links, forms, and other content for toggling -->
		  <div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav">
		    <li><a href="{{ url('/') }}">Home</a></li>
	
			</ul>
			 <ul class="nav navbar-nav navbar-right">
			 	
	            </ul>
			</div><!-- /.navbar-collapse --> 
		</div>	
</nav>

	
	
	<div class="container">
		<div class="row">
			<h3>Not Eligible</h3>
			<hr />
			<p>We’re sorry. You do not meet the 
				qualifications for this survey.</p>
			<p> We sincerely thank you and appreciate your time.</p>
			<p>
				If you have any questions or require further information please contact the principal 
				researcher. Similarly, for feedback on the research please email your request 
				to the principal researcher who will share this with you on 29th August 2016. 
				Contact details are provided below.
				<br />
				<b>Principal Researcher </b>
				<address>
				Rebecca Sharpe, <br />
				Masters Student, QUT<br />
				<b>Phone:</b> +61 7 3138 5123 <br />
				<b>Email:</b> <a href="mailto:rebecca.sharpe@hdr.qut.edu.au">rebecca.sharpe@hdr.qut.edu.au</a>
				</address>
			</p>

		</div>
	</div><!-- /container -->
	


	
</body>
</html>
