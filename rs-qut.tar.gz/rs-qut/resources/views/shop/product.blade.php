@extends('app')

@section('content')
	@include('shop.left')
	<!-- CONTENT SIDE-->

	<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
		
		<!-- MAIN PRODUCTS GRID-->
	<div class="container-folio row">
		@if($products)			
				<!-- PROD GRID 
				============================================================ -->
				
				<!-- PROD. ITEM -->
			@foreach($products as $product)
				 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
					<div class="thumbnail" style="padding:20px 0 0 10px;">
						<!-- IMAGE CONTAINER-->
						<img class="img-responsive" width="150px" src="{{asset($product->image)}}" alt="{{$product->name}}"
						data-toggle="tooltip" data-placement="top" title="Earn {{$product->point}} points."
						>
						<!--END IMAGE CONTAINER-->
						<!-- CAPTION -->
						<div class="caption">
							<h3 class="" alt="{{$product->name}}">

								<?php 
									// if (strlen($product->name) > 20) {
									// 	$start = substr($product->name, 0, 20);
									// 	$end = substr($product->name, -5);
									// 	echo $start.'...'.$end;
									// }else{
										echo $product->name;
									// }

								?>
							 </h3>
							<p class="text-muted">{{$product->description}}</p>
							
							<div class="row">
								<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<p class="lead">${{$product->price}}</p>
								</div>
								<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<input  type="hidden" class="product_id" value="{{$product->id}}"  />
									<button class="btn btn-success btn-block add-cart" >Add to cart</button>
								</div>
							</div>
						</div> 
						<!--END CAPTION -->
					</div>
					<!-- END: THUMBNAIL -->
				</div>
				<!-- PROD. ITEM -->
			@endforeach
				
		@else
			<h3>No Data</h3>
		@endif
				
			
				
				<!-- / PROD GRID 
				======================================= -->
</div>
<!-- /INNER ROW-->
			<hr>
<!-- PAGINATION-->
{!! str_replace('/?', '?', $products->render()) !!}
<!-- /PAGINATION-->
</div>
<!-- /CONTENT SIDE-->
<script type="text/javascript">
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip('show');

	var base_url = '<?php echo url('/');?>';
  $('.add-cart').click(function(){  
  	var cart_btn = $(this); //clicked button
  	var pid = cart_btn.parent().children("input.product_id").val();
    $.ajax({
      url: base_url+'/addToCart',
      type: "get",
      data: {'product_id': pid},
      success: function(data){
      	
      	$('#cartInfo').html(data[0]+" items: $"+data[1]+" <br> View Cart.");
         confirm("Product added");
if (data[2]) {

         	window.location = base_url+'/checkout';
         };
      }
    });      
  }); 
});
</script>


@endsection
