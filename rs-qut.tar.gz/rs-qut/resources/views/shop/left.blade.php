	<!-- LEFT SIDE CATEGORIES-->   
	<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">         
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Shop by Category</h4>
			</div>
			<div class="panel-body">
				<ul id="cat-navi" class="nav nav-list">
				  <li class="active"><a href="{{url('category',['Toiletries'])}}">Toiletries</a></li>
				  <li><a href="{{url('category',['Home and Outdoor'])}}">Home and Outdoor</a></li>
				  <li><a href="{{url('category',['Chilled'])}}">Chilled</a></li>
				  
				</ul>
			</div>
		</div>
	
		<!-- <div class="panel panel-default visible-lg">	
			<div class="panel-heading">
				<h4>Most Popular</h4>
			</div>
				<div class="panel-body">
					<ul id="cat-navi2" class="nav nav-list ">
					  <li class="active"><a href="#">Active category</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					  <li><a href="#">Category title</a></li>
					</ul>
				</div>
		</div> -->
			
			<!-- panel OFFER-->
			<!-- <div class="visible-lg">
				<div class="panel panel-success text-center">
					<div class="panel-body">
						<p class="lead"> SPECIAL OFFER DISCOUNT -20% </p>
					</div>
				</div>
			</div> -->
			<!-- / panel OFFER-->
			
			<!-- panel OFFER-->
			<!-- <div class="visible-lg">
				<div class="panel panel-success text-center">
					<div class="panel-body">
						<p class="lead"> SPECIAL DISCOUNT ON ALL PRODUCTS </p>
					</div>
				</div>
			</div> -->
			<!-- / panel OFFER-->
			
			<!-- panel OFFER-->
			<!-- <div class="visible-lg">
				<div class="panel panel-success text-center">
					<div class="panel-body">
						<p class="lead"> SPECIAL OFFER DISCOUNT -20% </p>
					</div>
				</div>
			</div> -->
			<!-- / panel OFFER-->
			
			<!-- panel OFFER-->
			<!-- <div class="visible-lg">
				<div class="panel panel-success text-center">
					<div class="panel-body">
						<p class="lead"> SPECIAL OFFER DISCOUNT -20% </p>
					</div>
				</div>
			</div> -->
			<!-- / panel OFFER-->
			
	</div>
	<!-- /left SIDE--> 