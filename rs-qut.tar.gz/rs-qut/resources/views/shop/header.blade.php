    <!-- PAGE-HEADER-->
	<div class="page-header" style="padding-top:20px;">
		<div class="container">
			<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 pull-right" style="z-index:1020 !important; padding:10px;">
				<ul class="nav nav-pills pull-right" style="width:100%;">
					<li class"dropdown active">
						<a class="" href="{{url('view-cart')}}" style="color: #ffffff; background-color: #50a8e1;">
						<i class="glyphicon glyphicon-shopping-cart"></i><br> Checkout</a>
					</li>
					 <li class="dropdown active" style="">
						<a id="cartInfo" class="dropdown-toggle text-center" href="{{url('view-cart')}}" style="width:100%;">
							<i class="icon-shopping-cart"></i>
							<?php echo Cart::count().' items: $'.Cart::total(). '<br> View Cart.'; ?>
							  <!-- Your Bag: $0.00 <i class="icon-caret-down"></i> -->
						</a>
						<!-- <ul class="dropdown-menu list-group pull-right dropdown-cart">
							<li>
								<a href="#" class="list-group-item active">
								<h4 class="list-group-item-heading"><i class="icon-shopping-cart"></i> CART HEADING</h4>
								<p class="list-group-item-text">Your Bag is empty </p>
								</a>
								<a href="#" class="list-group-item">
								<span class="badge"><i class="icon-chevron-right"></i></span>
								Product title here
								</a>
								<a href="#" class="list-group-item">
								<span class="badge"><i class="icon-chevron-right"></i></span>
								Product title here
								</a>
								<a href="#" class="list-group-item">
								<span class="badge badge-danger">$14</span>
								Product title here
								</a>
								<a href="#" class="list-group-item">
								<span class="badge">$14</span>
								Product title here Product 
								</a>
								<a class="btn btn-success navbar-btn" style="margin:5px; color:#fff;" >Proceed to checkout</a>
							</li>
						</ul> -->
					</li>
				</ul>
						</div>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-3 visible-lg text-center">
						<h1 style="margin-top:0px !important;">YOUR GROCER</h1>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="margin-bottom:10px;">
							<div id="myclock" ></div>

				
					</div>
			</div>
			
			
      </div>
</div>
</div>
<!-- /.page-header -->

<script type="text/javascript">
// Instantiate a counter
var base_url = '<?php echo url('/');?>';
var clock;
				clock = new FlipClock($('#myclock'), <?php if (Session::has('time_left'))
									{
										$value = Session::get('time_left');
									    echo $value;
									}
									else{
										echo '0';
									} ?>, {
					clockFace: 'MinuteCounter',
					autoStart: true,
					countdown: true,
					callbacks: {
							stop: redirectToSurvery,
		        	interval: function() {
		        		// console.log("destroy");
		        		var time_now = this.factory.getTime().time;
		        		 $.ajax({
							      url: base_url+'/setTimer',
							      type: "get",
							      data: {'time': time_now},
							      success: function(data){
							        // console.log("ajax complete");
							      }
							  	});
		        	}
		        }
				});

function redirectToSurvery() 
{ 
    window.location = "{{url('timer-co')}}";
}				


</script>
