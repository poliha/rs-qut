<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Your Grocer</title>

	<link href="{{ asset('/css/app.css') }}" rel="stylesheet">
	<link href="{{ asset('/css/bootstrap-classic-plus-theme.css') }}" rel="stylesheet">

	<link href="{{ asset('/css/jquery.mCustomScrollbar.css') }}" rel="stylesheet">
	
	<!-- Fonts -->
	<link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>

	<link href="{{asset('/css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{ asset('/css/shop.css') }}" rel="stylesheet">
	<link href="{{asset('/css/flipclock.css')}}" rel="stylesheet">

		<!-- Scripts -->
	<script src="{{ asset('/js/jquery.min.js')}}"></script>
	<script src="{{ asset('/js/bootstrap.min.js')}}"></script>
	<script src="{{ asset('/js/flipclock.min.js')}}"></script>
<!--[if lt IE 7]>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->
    <!-- Fav and touch icons -->


<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js" type="text/javascript"></script>
    <![endif]-->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<style type="text/css">
		.make-blue{
			text-transform: uppercase;
			color: #3299dc;
			font-size: larger;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
		<div class="container">
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
			  <span class="sr-only">Toggle navigation</span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="{{ url('/') }}">YOUR GROCER</a>
		  </div>

		  <!-- Collect the nav links, forms, and other content for toggling -->
		  <div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav">
		    
			</ul>
			 <ul class="nav navbar-nav navbar-right">
			 	
	            </ul>
			</div><!-- /.navbar-collapse --> 
		</div>	
</nav>

	
	
	<!-- MAIN CONTAINER-->
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 col-lg-8 col-lg-offset-2">
		
		<!-- MAIN PRODUCTS GRID-->
	
			@if($letters)			
					<div class="caption">
						<br>
						<br>
						<?php echo $letters->content; ?>
						<a href="{{url('start-shopping', ['lt' => $letters->id])}}" class="btn btn-success">Start Shopping</a>
					</div> 
						<!--END CAPTION -->
			
				
		@else
			<h3>No Data</h3>
		@endif
				
			
				
				<!-- / PROD GRID 
				======================================= -->
</div>
<!-- /INNER ROW-->
			<hr>

<!-- /CONTENT SIDE-->



		</div>
	</div><!-- /container -->
	


	
</body>
</html>
