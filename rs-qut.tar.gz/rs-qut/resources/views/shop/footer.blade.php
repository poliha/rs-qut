<!-- FOOTER-->
<footer class="">
<div class="container">
<div class="row">
    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <h4 class="line3 center standart-h4title"><span>Navigation</span></h4>
        <ul class="footer-links">
          <li><a href="#">Home</a></li>
          <li><a href="#">project</a></li>
          <li><a href="#">Elements</a></li>
          <li><a href="#">Contact</a></li>
          <li><a href="#">Blog</a></li>
        </ul>
    </div>
	  
    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <h4 class="line3 center standart-h4title"><span>Useful Links</span></h4>
        <ul class="footer-links">
          <li><a href="#">Yourcompany.com</a></li>
          <li><a href="#">Yourcompany.com</a></li>
         <li><a href="#">Yourcompany.com</a></li>
         <li><a href="#">Yourcompany.com</a></li>
         <li><a href="#">Bootstrap templates</a></li>
        </ul>
    </div> 
	  
    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <h4 class="line3 center standart-h4title"><span>Useful Links</span></h4>
        <ul class="footer-links">
          <li><a href="#">Yourcompany.com</a></li>
          <li><a href="#">Yourcompany.com</a></li>
		<li><a href="#">Yourcompany.com</a></li>
         <li><a href="#">Yourcompany.com</a></li>
         <li><a href="#">Bootstrap templates</a></li>
        </ul>
    </div>
	
    <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <h4 class="line3 center standart-h4title"><span>Our office</span></h4>
		<address>
			<strong>YourCompany.com, LLC.</strong><br>
			<i class="fa-icon-map-marker"></i> Address Line 1<br>
			Address Line 2<br>
			<i class="fa-icon-phone-sign"></i> + 1 (123) 456-7890
		
		</address>
    </div> 
</div>
	<hr> 
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-lg-12 ">
					<p>© yourcompany.com Company 2013</p>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- /Footer-->