@extends('app')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<h3>Shoping Cart</h3>
	</div>
	
		<div class="panel-body">
			<div class="row">
				<div class="col-12 col-lg-12">
						<table class="table table-striped">
							<thead>
							  <tr>
							  <th></th>
								<th>Item</th>
								<th>Qty</th>
								<th>Price</th>
								<th>Total</th>
							  </tr>
							</thead>
							<tbody>
								@foreach($items as $item)
							  <tr>
							  <td>
							  	<input  type="hidden" class="row_id" value="{{$item->rowid}}"  />
							  	<input  type="hidden" class="product_id" value="{{$item->id}}"  />
									<button class="btn btn-danger btn-sm btn-block remove-cart" >Remove</button>
							  </td>
								<td>{{$item->name}}</td>
								<td>{{$item->qty}}</td>
								<td>${{$item->price}}</td>
								<td>${{$item->subtotal}}</td>
							  </tr>
							  @endforeach
							</tbody>
					  </table>
					  <hr>
						<dl class="dl-horizontal pull-right">
						  <dt>Sub-total:</dt>
						  <dd>${{$total_price}}</dd>
						  <dt>Shipping Cost:</dt>
						  <dd>$0.00</dd> 
						  <dt>Total:</dt>
						  <dd>${{$total_price}}</dd>
						</dl>
						<div class="clearfix"></div>
						
				</div>
			</div>
		</div>
		<div class="panel-footer">
			<div class="row">
				<div class="col-lg-12">
					 <a href="{{url('checkout')}}"  class="btn btn-success pull-right"><i class="icon-ok-sign"></i> Proceed to checkout</a>
				</div>
			</div>
		</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	var base_url = '<?php echo url('/');?>';
  $('.remove-cart').click(function(){  
  	var cart_btn = $(this); //clicked button
  	var rid = cart_btn.parent().children("input.row_id").val();
  	var pid = cart_btn.parent().children("input.product_id").val();
    $.ajax({
      url: base_url+'/removeCart',
      type: "get",
      data: {'row_id': rid, 'product_id': pid},
      success: function(data){
      	
      	//$('#cartInfo').html(data+" items. View Cart.");
        // alert("Product added");
       	$('#cartInfo').html(data+" items. View Cart.");
        location.reload();
      }
    });      
  }); 
});
</script>
@endsection