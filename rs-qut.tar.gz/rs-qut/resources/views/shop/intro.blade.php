@extends('app')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<h3>Questionnaire Section</h3>
	</div>
	
		<div class="panel-body">
			<div class="row">
				<div class="col-12 col-lg-12">
						<p>
							Thank you for shopping with us. Please help us answer a few questions by 
							clicking "Start Questionnaire" button below.
						</p>
				</div>
			</div>
		</div>
		<div class="panel-footer">
			<div class="row">
				<div class="col-lg-12">
					 <a href="{{url('start-survey')}}"  class="btn btn-lg btn-success pull-right">
					 	<i class="icon-ok-sign"></i> Start Questionnaire</a>
				</div>
			</div>
		</div>
</div>

@endsection