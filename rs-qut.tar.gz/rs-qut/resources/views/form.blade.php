<html>
<head>

	<link href="{{ asset('/css/bootstrap.min.css') }}" rel="stylesheet">
	<link href="{{ asset('/css/form.css') }}" rel="stylesheet">

	<!-- Scripts -->
	<script src="{{ asset('/js/jquery.min.js')}}"></script>
	<script src="{{ asset('/js/bootstrap.min.js')}}"></script>
	<script src="{{ asset('/js/jquery.easing.min.js')}}"></script>

	<script type="text/javascript">
	$( document ).ready(function() {
			//jQuery time
			var current_fs, next_fs, previous_fs; //fieldsets
			var left, opacity, scale; //fieldset properties which we will animate
			var animating; //flag to prevent quick multi-click glitches

			$(".next").click(function(){
				if(animating) return false;
				animating = true;
				
				current_fs = $(this).parent();
				next_fs = $(this).parent().next();
				
				//activate next step on progressbar using the index of next_fs
				$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
				
				//show the next fieldset
				next_fs.show(); 
				//hide the current fieldset with style
				current_fs.animate({opacity: 0}, {
					step: function(now, mx) {
						//as the opacity of current_fs reduces to 0 - stored in "now"
						//1. scale current_fs down to 80%
						scale = 1 - (1 - now) * 0.2;
						//2. bring next_fs from the right(50%)
						left = (now * 50)+"%";
						//3. increase opacity of next_fs to 1 as it moves in
						opacity = 1 - now;
						current_fs.css({'transform': 'scale('+scale+')'});
						next_fs.css({'left': left, 'opacity': opacity});
						window.scrollTo(0, 0);
					}, 
					duration: 800, 
					complete: function(){
						current_fs.hide();
						animating = false;
					}, 
					//this comes from the custom easing plugin
					easing: 'easeInOutBack'
				});
			});

			$(".previous").click(function(){
				if(animating) return false;
				animating = true;
				
				current_fs = $(this).parent();
				previous_fs = $(this).parent().prev();
				
				//de-activate current step on progressbar
				$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
				
				//show the previous fieldset
				previous_fs.show(); 
				//hide the current fieldset with style
				current_fs.animate({opacity: 0}, {
					step: function(now, mx) {
						//as the opacity of current_fs reduces to 0 - stored in "now"
						//1. scale previous_fs from 80% to 100%
						scale = 0.8 + (1 - now) * 0.2;
						//2. take current_fs to the right(50%) - from 0%
						left = ((1-now) * 50)+"%";
						//3. increase opacity of previous_fs to 1 as it moves in
						opacity = 1 - now;
						current_fs.css({'left': left});
						previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
						window.scrollTo(0, 0);
					}, 
					duration: 800, 
					complete: function(){
						current_fs.hide();
						animating = false;
					}, 
					//this comes from the custom easing plugin
					easing: 'easeInOutBack'
				});
			});

			// $(".submit").click(function(){
			// 	return false;
			// })
			
			var base_url = '<?php echo url('/');?>';
  $('.pcsearch').click(function(){  
  	var pcquery = $('#pcquery').val(); 
  if (pcquery.length < 3) {
  	alert("Minimum search string length is 3");
  } 
  else{
  	 	$('#ajax-loader').removeClass("hide");
  	
  	console.log(pcquery);
  	var options = '';

    $.ajax({
      url: base_url+'/getsurburb',
      type: "get",
      dataType: "json",
      data: {'pcquery': pcquery},
      success: function(data){
        console.log(data);

        if (data.localities.length == 0) {
        	options +='<option>None Found</option>';
        } 
        else{
        	options +='<option>Choose One</option>';
        	for (var i = 0; i < data.localities.locality.length; i++) {
        	console.log	(data.localities.locality[i]['location']);
        	options +='<option value="'+data.localities.locality[i]['postcode']+'">'+data.localities.locality[i]['location']+'/'+data.localities.locality[i]['state']+'<option/>';
        	};	
        };

        

      	$("#postcode").html(options);
      	$('#ajax-loader').addClass("hide");
        // $.each(obj, function(key,value) {
  		// 			console.log(value.localities);
				// }); 
       }
    });
  };

       
  }); 

			});

	</script>
</head>

<body>

<!-- multistep form -->
<form id="msform" role="form" method="POST" action="{{ url('/submit-survey') }}">
	<input type="hidden" name="_token" value="{{ csrf_token() }}">
	<!-- progressbar -->
	<ul id="progressbar">
		<li class="active">Start</li>
		<li>42%</li>
		<li>50%</li>
		<li>66%</li>
		<li>75%</li>
		<li>Complete</li>
		
	</ul>
	<!-- Errors -->
	@if (count($errors) > 0)
		<div class="alert alert-danger alert-dismissible">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<strong>Whoops!</strong> There were some problems with your input.<br><br>
			<ul>
				@foreach ($errors->all() as $error)
					<li>{{ $error }}</li>
				@endforeach
			</ul>
		</div>
	@endif


	<fieldset id="appendixB">
		<!-- <h2 class="fs-title">Appendix B</h2> -->
		<div class="question-block">
			<!-- <span>Question 5.</span> -->
			<br>
			<label>First, read each item and then, circle the number that most appropriately describes the extent you are experiencing these feelings and emotions right now.</label>
			<br>
			<br>
			<strong>At this moment I am feeling:</strong>
			<br>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th></th>
							<th>Feelings</th>
							<th>Slightly or nil</th>
							<th>A little</th>
							<th>Moderately</th>
							<th>Quite a bit</th>
							<th>Extremely</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>5a.</td>
							<td>Interested</td>
							<td><input type="radio" name="question5a" value="1" ></td>
							<td><input type="radio" name="question5a" value="2" ></td>
							<td><input type="radio" name="question5a" value="3" ></td>
							<td><input type="radio" name="question5a" value="4" ></td>
							<td><input type="radio" name="question5a" value="5" ></td>
						</tr>
						<tr>
							<td>5b.</td>
							<td>Irritable</td>
							<td><input type="radio" name="question5b" value="1" ></td>
							<td><input type="radio" name="question5b" value="2" ></td>
							<td><input type="radio" name="question5b" value="3" ></td>
							<td><input type="radio" name="question5b" value="4" ></td>
							<td><input type="radio" name="question5b" value="5" ></td>
						</tr>	
						<tr>
							<td>5c.</td>
							<td>Determined</td>
							<td><input type="radio" name="question5c" value="1" ></td>
							<td><input type="radio" name="question5c" value="2" ></td>
							<td><input type="radio" name="question5c" value="3" ></td>
							<td><input type="radio" name="question5c" value="4" ></td>
							<td><input type="radio" name="question5c" value="5" ></td>
						</tr>
						<tr>
							<td>5d.</td>
							<td>Nervous</td>
							<td><input type="radio" name="question5d" value="1" ></td>
							<td><input type="radio" name="question5d" value="2" ></td>
							<td><input type="radio" name="question5d" value="3" ></td>
							<td><input type="radio" name="question5d" value="4" ></td>
							<td><input type="radio" name="question5d" value="5" ></td>
						</tr>
						<tr>
							<td>5e.</td>
							<td>Alert</td>
							<td><input type="radio" name="question5e" value="1" ></td>
							<td><input type="radio" name="question5e" value="2" ></td>
							<td><input type="radio" name="question5e" value="3" ></td>
							<td><input type="radio" name="question5e" value="4" ></td>
							<td><input type="radio" name="question5e" value="5" ></td>
						</tr>	
						<tr>
							<td>5f.</td>
							<td>Strong</td>
							<td><input type="radio" name="question5f" value="1" ></td>
							<td><input type="radio" name="question5f" value="2" ></td>
							<td><input type="radio" name="question5f" value="3" ></td>
							<td><input type="radio" name="question5f" value="4" ></td>
							<td><input type="radio" name="question5f" value="5" ></td>
						</tr>															
						<tr>
							<td>5g.</td>
							<td>Distressed</td>
							<td><input type="radio" name="question5g" value="1" ></td>
							<td><input type="radio" name="question5g" value="2" ></td>
							<td><input type="radio" name="question5g" value="3" ></td>
							<td><input type="radio" name="question5g" value="4" ></td>
							<td><input type="radio" name="question5g" value="5" ></td>
						</tr>															
						<tr>
							<td>5h.</td>
							<td>Excited</td>
							<td><input type="radio" name="question5h" value="1" ></td>
							<td><input type="radio" name="question5h" value="2" ></td>
							<td><input type="radio" name="question5h" value="3" ></td>
							<td><input type="radio" name="question5h" value="4" ></td>
							<td><input type="radio" name="question5h" value="5" ></td>
						</tr>										
						<tr>
							<td>5i.</td>
							<td>Upset</td>
							<td><input type="radio" name="question5i" value="1" ></td>
							<td><input type="radio" name="question5i" value="2" ></td>
							<td><input type="radio" name="question5i" value="3" ></td>
							<td><input type="radio" name="question5i" value="4" ></td>
							<td><input type="radio" name="question5i" value="5" ></td>
						</tr>						
						<tr>
							<td>5j.</td>
							<td>Ashamed</td>
							<td><input type="radio" name="question5j" value="1" ></td>
							<td><input type="radio" name="question5j" value="2" ></td>
							<td><input type="radio" name="question5j" value="3" ></td>
							<td><input type="radio" name="question5j" value="4" ></td>
							<td><input type="radio" name="question5j" value="5" ></td>
						</tr>
						<tr>
							<td>5k.</td>
							<td>Inspired</td>
							<td><input type="radio" name="question5k" value="1" ></td>
							<td><input type="radio" name="question5k" value="2" ></td>
							<td><input type="radio" name="question5k" value="3" ></td>
							<td><input type="radio" name="question5k" value="4" ></td>
							<td><input type="radio" name="question5k" value="5" ></td>
						</tr>												
						<tr>
							<td>5l.</td>
							<td>Scared</td>
							<td><input type="radio" name="question5l" value="1" ></td>
							<td><input type="radio" name="question5l" value="2" ></td>
							<td><input type="radio" name="question5l" value="3" ></td>
							<td><input type="radio" name="question5l" value="4" ></td>
							<td><input type="radio" name="question5l" value="5" ></td>
						</tr>						
						<tr>
							<td>5m.</td>
							<td>Guilty</td>
							<td><input type="radio" name="question5m" value="1" ></td>
							<td><input type="radio" name="question5m" value="2" ></td>
							<td><input type="radio" name="question5m" value="3" ></td>
							<td><input type="radio" name="question5m" value="4" ></td>
							<td><input type="radio" name="question5m" value="5" ></td>
						</tr>						
						<tr>
							<td>5n.</td>
							<td>Attentive</td>
							<td><input type="radio" name="question5n" value="1" ></td>
							<td><input type="radio" name="question5n" value="2" ></td>
							<td><input type="radio" name="question5n" value="3" ></td>
							<td><input type="radio" name="question5n" value="4" ></td>
							<td><input type="radio" name="question5n" value="5" ></td>
						</tr>						
						<tr>
							<td>5o.</td>
							<td>Hostile</td>
							<td><input type="radio" name="question5o" value="1" ></td>
							<td><input type="radio" name="question5o" value="2" ></td>
							<td><input type="radio" name="question5o" value="3" ></td>
							<td><input type="radio" name="question5o" value="4" ></td>
							<td><input type="radio" name="question5o" value="5" ></td>
						</tr>	
						<tr>
							<td>5p.</td>
							<td>Enthusiastic</td>
							<td><input type="radio" name="question5p" value="1" ></td>
							<td><input type="radio" name="question5p" value="2" ></td>
							<td><input type="radio" name="question5p" value="3" ></td>
							<td><input type="radio" name="question5p" value="4" ></td>
							<td><input type="radio" name="question5p" value="5" ></td>
						</tr>											
						<tr>
							<td>5q.</td>
							<td>Jittery</td>
							<td><input type="radio" name="question5q" value="1" ></td>
							<td><input type="radio" name="question5q" value="2" ></td>
							<td><input type="radio" name="question5q" value="3" ></td>
							<td><input type="radio" name="question5q" value="4" ></td>
							<td><input type="radio" name="question5q" value="5" ></td>
						</tr>						
						<tr>
							<td>5r.</td>
							<td>Active</td>
							<td><input type="radio" name="question5r" value="1" ></td>
							<td><input type="radio" name="question5r" value="2" ></td>
							<td><input type="radio" name="question5r" value="3" ></td>
							<td><input type="radio" name="question5r" value="4" ></td>
							<td><input type="radio" name="question5r" value="5" ></td>
						</tr>						
						<tr>
							<td>5s.</td>
							<td>Proud</td>
							<td><input type="radio" name="question5s" value="1" ></td>
							<td><input type="radio" name="question5s" value="2" ></td>
							<td><input type="radio" name="question5s" value="3" ></td>
							<td><input type="radio" name="question5s" value="4" ></td>
							<td><input type="radio" name="question5s" value="5" ></td>
						</tr>						
						<tr>
							<td>5t.</td>
							<td>Afraid</td>
							<td><input type="radio" name="question5t" value="1" ></td>
							<td><input type="radio" name="question5t" value="2" ></td>
							<td><input type="radio" name="question5t" value="3" ></td>
							<td><input type="radio" name="question5t" value="4" ></td>
							<td><input type="radio" name="question5t" value="5" ></td>
						</tr>						
					</tbody>
				</table>
			</div>
		</div>


		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	<fieldset  id="appendixC">
		<!-- <h2 class="fs-title">Appendix C</h2> -->
		<div class="question-block">
			<!-- <span>Question 6.</span> -->
			<br>
			<label>Choose the response to the statement that best describes you.</label>
			<br>
			
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Statement</th>
							<th>Response A</th>
							<th>Response B</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>6a. When I know I must finish something soon...</td>
							<td><input type="radio" name="question6a" value="1" > I have to push myself to get started.</td>
							<td><input type="radio" name="question6a" value="2" > I find it easy to get it over and done with.</td>
						</tr>
						<tr>
							<td>6b. When I am getting ready to tackle a difficult problem...</td>
							<td><input type="radio" name="question6b" value="1" > It feels like I am facing a big mountain I don't think I can climb.</td>
							<td><input type="radio" name="question6b" value="2" > I look for a way to approach the problem in a suitable manner.</td>
						</tr>	
						<tr>
							<td>6c. When I have a boring task...</td>
							<td><input type="radio" name="question6c" value="1" > I usually don't have a problem getting through it.</td>
							<td><input type="radio" name="question6c" value="2" > I Sometimes just can't get moving on it.</td>
						</tr>
						<tr>
							<td>6d. When I have lost something that is very valuable to me and I can't find it anywhere...</td>
							<td><input type="radio" name="question6d" value="1" > I have a hard time concentrating on anything else.</td>
							<td><input type="radio" name="question6d" value="2" > I put it out of my mind after a little while.</td>
						</tr>
						<tr>
							<td>6e. If I've spent a lot of time looking for a product and that product becomes no longer available before I have made the purchase...</td>
							<td><input type="radio" name="question6e" value="1" > It takes me a long time to adjust myself to it.</td>
							<td><input type="radio" name="question6e" value="2" > It bothers me for a while, but then I don't think about it anymore.</td>
						</tr>	
						<tr>
							<td>6f. When I am being told that the items that I have bought are completely unsatisfactory for their intended purpose...</td>
							<td><input type="radio" name="question6f" value="1" > I don't let it bother me for too long.</td>
							<td><input type="radio" name="question6f" value="2" >  I feel paralysed.</td>
						</tr>															
						
					</tbody>
				</table>
			</div>

		</div>

		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	<fieldset id="appendixD">
		<!-- <h2 class="fs-title">Appendix D</h2> -->
		<div class="question-block">
			<!-- <span>Question 7</span> -->
			<br>
			<label>Please respond to each of the four statements below. </label>
			<br>

			<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<tr>
								<th></th>
								<th>Strongly disagree</th>
								<th>Disagree somewhat</th>
								<th>Disagree</th>
								<th>Undecided</th>
								<th>Agree somewhat</th>
								<th>Agree</th>
								<th>Strongly agree</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>7a. It was fully clear to me why and how I was to use the customer loyalty programme rewards letter.</td>
								<td><input type="radio" name="question7a" value="1" ></td>
								<td><input type="radio" name="question7a" value="2" ></td>
								<td><input type="radio" name="question7a" value="3" ></td>
								<td><input type="radio" name="question7a" value="4" ></td>
								<td><input type="radio" name="question7a" value="5" ></td>
								<td><input type="radio" name="question7a" value="6" ></td>
								<td><input type="radio" name="question7a" value="7" ></td>
							</tr>
							<tr>
								<td>7b. I was uncertain why and how I was to use the customer loyalty programme rewards letter.</td>
								<td><input type="radio" name="question7b" value="1" ></td>
								<td><input type="radio" name="question7b" value="2" ></td>
								<td><input type="radio" name="question7b" value="3" ></td>
								<td><input type="radio" name="question7b" value="4" ></td>
								<td><input type="radio" name="question7b" value="5" ></td>
								<td><input type="radio" name="question7b" value="6" ></td>
								<td><input type="radio" name="question7b" value="7" ></td>
							</tr>
							<tr>
								<td>7c. I intend to buy products that will earn me rewards points.</td>
								<td><input type="radio" name="question7c" value="1" ></td>
								<td><input type="radio" name="question7c" value="2" ></td>
								<td><input type="radio" name="question7c" value="3" ></td>
								<td><input type="radio" name="question7c" value="4" ></td>
								<td><input type="radio" name="question7c" value="5" ></td>
								<td><input type="radio" name="question7c" value="6" ></td>
								<td><input type="radio" name="question7c" value="7" ></td>
							</tr>
							<tr>
								<td>7d. I am not planning to buy products that will earn me rewards points.</td>
								<td><input type="radio" name="question7d" value="1" ></td>
								<td><input type="radio" name="question7d" value="2" ></td>
								<td><input type="radio" name="question7d" value="3" ></td>
								<td><input type="radio" name="question7d" value="4" ></td>
								<td><input type="radio" name="question7d" value="5" ></td>
								<td><input type="radio" name="question7d" value="6" ></td>
								<td><input type="radio" name="question7d" value="7" ></td>
							</tr>
						</tbody>
					</table>
			</div>
		</div>

		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />

		
	</fieldset>
	
	<fieldset id="appendixD2">
		<div class="question-block">
			<!-- <span>Question 8</span> -->
			<br>
			<label>Please indicate your level of agreement towards the following statements using a scale from 1 to 7 where 1 means "Strongly agree" and 7 means "Strongly disagree."</label>
			<br>

			<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<tr>
								<th></th>
								<th>Strongly disagree</th>
								<th>Disagree somewhat</th>
								<th>Disagree</th>
								<th>Undecided</th>
								<th>Agree somewhat</th>
								<th>Agree</th>
								<th>Strongly agree</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>8a. I believe that this grocery store rewards me for my purchases.</td>
								<td><input type="radio" name="question8a" value="1" ></td>
								<td><input type="radio" name="question8a" value="2" ></td>
								<td><input type="radio" name="question8a" value="3" ></td>
								<td><input type="radio" name="question8a" value="4" ></td>
								<td><input type="radio" name="question8a" value="5" ></td>
								<td><input type="radio" name="question8a" value="6" ></td>
								<td><input type="radio" name="question8a" value="7" ></td>
							</tr>
							<tr>
								<td>8b. I believe that earning rewards points for my purchases are of value to me.</td>
								<td><input type="radio" name="question8b" value="1" ></td>
								<td><input type="radio" name="question8b" value="2" ></td>
								<td><input type="radio" name="question8b" value="3" ></td>
								<td><input type="radio" name="question8b" value="4" ></td>
								<td><input type="radio" name="question8b" value="5" ></td>
								<td><input type="radio" name="question8b" value="6" ></td>
								<td><input type="radio" name="question8b" value="7" ></td>
							</tr>
							<tr>
								<td>8c. I have a negative attitude towards this customer loyalty programme.</td>
								<td><input type="radio" name="question8c" value="1" ></td>
								<td><input type="radio" name="question8c" value="2" ></td>
								<td><input type="radio" name="question8c" value="3" ></td>
								<td><input type="radio" name="question8c" value="4" ></td>
								<td><input type="radio" name="question8c" value="5" ></td>
								<td><input type="radio" name="question8c" value="6" ></td>
								<td><input type="radio" name="question8c" value="7" ></td>
							</tr>
							<tr>
								<td>8d. The statement of "I see benefit in shopping at a store that rewards me for my loyalty" is true.</td>
								<td><input type="radio" name="question8d" value="1" ></td>
								<td><input type="radio" name="question8d" value="2" ></td>
								<td><input type="radio" name="question8d" value="3" ></td>
								<td><input type="radio" name="question8d" value="4" ></td>
								<td><input type="radio" name="question8d" value="5" ></td>
								<td><input type="radio" name="question8d" value="6" ></td>
								<td><input type="radio" name="question8d" value="7" ></td>
							</tr>
							<tr>
								<td>8e. I would consider choosing this grocery store over other grocery stores because of the member's loyalty rewards on offer.</td>
								<td><input type="radio" name="question8e" value="1" ></td>
								<td><input type="radio" name="question8e" value="2" ></td>
								<td><input type="radio" name="question8e" value="3" ></td>
								<td><input type="radio" name="question8e" value="4" ></td>
								<td><input type="radio" name="question8e" value="5" ></td>
								<td><input type="radio" name="question8e" value="6" ></td>
								<td><input type="radio" name="question8e" value="7" ></td>
							</tr>
							<tr>
								<td>8f. I would not make a special effort to shop at a grocery store that rewards me for my purchases/repeat patronage.</td>
								<td><input type="radio" name="question8f" value="1" ></td>
								<td><input type="radio" name="question8f" value="2" ></td>
								<td><input type="radio" name="question8f" value="3" ></td>
								<td><input type="radio" name="question8f" value="4" ></td>
								<td><input type="radio" name="question8f" value="5" ></td>
								<td><input type="radio" name="question8f" value="6" ></td>
								<td><input type="radio" name="question8f" value="7" ></td>
							</tr>														
						</tbody>
					</table>
			</div>
		</div>
		
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>

	<fieldset id="appendixE">
		<!-- <h2 class="fs-title">Appendix E</h2> -->
		<div class="question-block">
			<!-- <span>Question 9</span> -->
			<br>
			<label>Considering the anchors on each end (for example Wise = 1 and Foolish = 7), please indicate your sentiment, levels of agreement and perceptions for each of the following questions.</label>
			<br>

			<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Statement</th>
								<th></th>
								<th>1</th>
								<th>2</th>
								<th>3</th>
								<th>4</th>
								<th>5</th>
								<th>6</th>
								<th>7</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td rowspan="3" style="vertical-align:middle;">9a. When shopping, making purchases in a store that I am a loyalty programme member of is... </td>
								<td>Wise</td>
								<td><input type="radio" name="question9a1" value="1" ></td>
								<td><input type="radio" name="question9a1" value="2" ></td>
								<td><input type="radio" name="question9a1" value="3" ></td>
								<td><input type="radio" name="question9a1" value="4" ></td>
								<td><input type="radio" name="question9a1" value="5" ></td>
								<td><input type="radio" name="question9a1" value="6" ></td>
								<td><input type="radio" name="question9a1" value="7" ></td>
								<td>Foolish</td>
							</tr>
							<tr>
								<td>Unpleasant</td>
								<td><input type="radio" name="question9a2" value="1" ></td>
								<td><input type="radio" name="question9a2" value="2" ></td>
								<td><input type="radio" name="question9a2" value="3" ></td>
								<td><input type="radio" name="question9a2" value="4" ></td>
								<td><input type="radio" name="question9a2" value="5" ></td>
								<td><input type="radio" name="question9a2" value="6" ></td>
								<td><input type="radio" name="question9a2" value="7" ></td>
								<td>Pleasant</td>
							</tr>
							<tr>
								<td>Good</td>
								<td><input type="radio" name="question9a3" value="1" ></td>
								<td><input type="radio" name="question9a3" value="2" ></td>
								<td><input type="radio" name="question9a3" value="3" ></td>
								<td><input type="radio" name="question9a3" value="4" ></td>
								<td><input type="radio" name="question9a3" value="5" ></td>
								<td><input type="radio" name="question9a3" value="6" ></td>
								<td><input type="radio" name="question9a3" value="7" ></td>
								<td>Bad</td>
							</tr>														
							<tr>
								<td>9b. People who influence my decisions would approve of me making purchase decisions based on loyalty reward incentives.?</td>
								<td>False</td>
								<td><input type="radio" name="question9b" value="1" ></td>
								<td><input type="radio" name="question9b" value="2" ></td>
								<td><input type="radio" name="question9b" value="3" ></td>
								<td><input type="radio" name="question9b" value="4" ></td>
								<td><input type="radio" name="question9b" value="5" ></td>
								<td><input type="radio" name="question9b" value="6" ></td>
								<td><input type="radio" name="question9b" value="7" ></td>
								<td>True</td>
							</tr>
							<tr>
								<td>9c. My close friends and family will go out of their way to make a purchase where they think that will gain some type of value or reward from the brand selling the product or service.</td>
								<td>Agree</td>
								<td><input type="radio" name="question9c" value="1" ></td>
								<td><input type="radio" name="question9c" value="2" ></td>
								<td><input type="radio" name="question9c" value="3" ></td>
								<td><input type="radio" name="question9c" value="4" ></td>
								<td><input type="radio" name="question9c" value="5" ></td>
								<td><input type="radio" name="question9c" value="6" ></td>
								<td><input type="radio" name="question9c" value="7" ></td>
								<td>Disagree</td>
							</tr>
							<tr>
								<td>9d. People who are important to me think I {<em>select statement from right</em>} be rewarded for my purchases.</td>
								<td>Should</td>
								<td><input type="radio" name="question9d" value="1" ></td>
								<td><input type="radio" name="question9d" value="2" ></td>
								<td><input type="radio" name="question9d" value="3" ></td>
								<td><input type="radio" name="question9d" value="4" ></td>
								<td><input type="radio" name="question9d" value="5" ></td>
								<td><input type="radio" name="question9d" value="6" ></td>
								<td><input type="radio" name="question9d" value="7" ></td>
								<td>Should not</td>
							</tr>
							<tr>
								<td>9e. How much control do you think you have over your purchase decisions?</td>
								<td>Full Control</td>
								<td><input type="radio" name="question9e" value="1" ></td>
								<td><input type="radio" name="question9e" value="2" ></td>
								<td><input type="radio" name="question9e" value="3" ></td>
								<td><input type="radio" name="question9e" value="4" ></td>
								<td><input type="radio" name="question9e" value="5" ></td>
								<td><input type="radio" name="question9e" value="6" ></td>
								<td><input type="radio" name="question9e" value="7" ></td>
								<td>No Control</td>
							</tr>
							<tr>
								<td>9f. For me, sticking to my purchases goals is...?</td>
								<td>Easy</td>
								<td><input type="radio" name="question9f" value="1" ></td>
								<td><input type="radio" name="question9f" value="2" ></td>
								<td><input type="radio" name="question9f" value="3" ></td>
								<td><input type="radio" name="question9f" value="4" ></td>
								<td><input type="radio" name="question9f" value="5" ></td>
								<td><input type="radio" name="question9f" value="6" ></td>
								<td><input type="radio" name="question9f" value="7" ></td>
								<td>Difficult</td>
							</tr>									
							<tr>
								<td>9g. Two stores both sell a product that you need (exactly the same and priced the same). The store of which you are a loyalty member of is harder to get to that than the store where you are not a member. How possible is it that you will make the effort to purchase from the store where you will be rewarded?</td>
								<td>Impossible</td>
								<td><input type="radio" name="question9g" value="1" ></td>
								<td><input type="radio" name="question9g" value="2" ></td>
								<td><input type="radio" name="question9g" value="3" ></td>
								<td><input type="radio" name="question9g" value="4" ></td>
								<td><input type="radio" name="question9g" value="5" ></td>
								<td><input type="radio" name="question9g" value="6" ></td>
								<td><input type="radio" name="question9g" value="7" ></td>
								<td>Possible</td>
							</tr>														
						</tbody>
					</table>
			</div>
		</div>		

	
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	
	<fieldset id="appendixF">
				<!-- <h2 class="fs-title">Appendix F</h2> -->
		<div class="question-block">
			<span>Question 10.</span>
			<br>
			<label>Where '<strong>ethnicity</strong>' refers to the shared identity or similarity of a group of people on the basis of one or more factors, select the one ethnic group that you belong to: </label>
			<br>

			<div class="row">
			  <div class="panel-group col-lg-6 col-md-6 col-sm-12 col-xs-12" id="accordion" role="tablist" aria-multiselectable="true">
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingOne">
			        <h4 class="panel-title">
			          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
			            OCEANIAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
			        <div class="panel-body">
									<input type="radio" name="question10" value="11" > Australian Peoples<br />
									<input type="radio" name="question10" value="12" > New Zealand Peoples<br />
									<input type="radio" name="question10" value="13" > Melanesian and Papuan<br />
									<input type="radio" name="question10" value="14" > Micronesian<br />
									<input type="radio" name="question10" value="15" > Polynesian
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingTwo">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
			            NORTH-WEST EUROPEAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
			        <div class="panel-body">
									<input type="radio" name="question10" value="21" > British<br />
									<input type="radio" name="question10" value="22" > Irish<br />
									<input type="radio" name="question10" value="23" > Western European<br />
									<input type="radio" name="question10" value="24" > Northern European
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingThree">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
			            SOUTHERN AND EASTERN EUROPEAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
			        <div class="panel-body">
									<input type="radio" name="question10" value="31" > Southern European<br />
									<input type="radio" name="question10" value="32" > South Eastern European<br />
									<input type="radio" name="question10" value="33" > Eastern European
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingFour">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
			            NORTH AFRICAN AND MIDDLE EASTERN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
			        <div class="panel-body">
									<input type="radio" name="question10" value="41" > Arab<br />
									<input type="radio" name="question10" value="42" > Jewish<br />
									<input type="radio" name="question10" value="43" > Peoples of the Sudan<br />
									<input type="radio" name="question10" value="44" > Other North African and Middle Eastern
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingFive">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
			            SOUTH-EAST ASIAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
			        <div class="panel-body">
								<input type="radio" name="question10" value="51" > Mainland South-East Asian<br />
								<input type="radio" name="question10" value="52" > Maritime South-East Asian<br />
			        </div>
			      </div>
			    </div>      
			  </div>

			  <div class="panel-group col-lg-6 col-md-6 col-sm-12 col-xs-12" id="accordion2" role="tablist" aria-multiselectable="true">
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingSix">
			        <h4 class="panel-title">
			          <a data-toggle="collapse" data-parent="#accordion2" href="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
			            NORTH-EAST ASIAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
			        <div class="panel-body">
								<input type="radio" name="question10" value="61" > Chinese Asian<br />
								<input type="radio" name="question10" value="62" > Other Nort-East Asian<br />
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingSeven">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
			            SOUTHERN AND CENTRAL ASIAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSeven">
			        <div class="panel-body">
								<input type="radio" name="question10" value="71" > Southern Asian<br />
								<input type="radio" name="question10" value="72" > Central Asian<br />
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingEight">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
			            PEOPLE OF THE AMERICAS
			          </a>
			        </h4>
			      </div>
			      <div id="collapseEight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEight">
			        <div class="panel-body">
									<input type="radio" name="question10" value="81" > North American<br />
									<input type="radio" name="question10" value="82" > South American<br />
									<input type="radio" name="question10" value="83" > Central American<br />
									<input type="radio" name="question10" value="84" > Caribbean Islander
			        </div>
			      </div>
			    </div>
			    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingNine">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
			            SUB-SAHARAN AFRICAN
			          </a>
			        </h4>
			      </div>
			      <div id="collapseNine" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingNine">
			        <div class="panel-body">
								<input type="radio" name="question10" value="91" > Central and West African<br />
								<input type="radio" name="question10" value="92" > Southern and East African<br />
			        </div>
			      </div>
			    </div>
			 <!--    <div class="panel panel-default">
			      <div class="panel-heading" role="tab" id="headingTen">
			        <h4 class="panel-title">
			          <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
			            Collapsible Group Item #10
			          </a>
			        </h4>
			      </div>
			      <div id="collapseTen" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTen">
			        <div class="panel-body">
			          Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
			        </div>
			      </div>
			    </div>  -->     
			  </div>
			</div>

		</div>
		<div class="question-block">
			<span>Question 11.</span>
			<br>
			<label>Please indicate your postcode:</label>
			<br>
			<input type="text" class="form-inline" name="pcquery" id="pcquery" placeholder="Enter postcode/suburb" />
			<a class="pcsearch btn btn-sm btn-info form-inline " href="#" >Search</a>
			<div id="pcarea">
				<label>Location: </label>
				<select id="postcode" name="question11" class="form-inline">
					<option>Enter Search above</option>
				</select>
				<img id="ajax-loader" class="hide" src="{{asset('/images/loading.gif')}}">
			</div>
			<br>
			
		</div>
		<div class="question-block">
			<span>Question 12.</span>
			<br>
			<label>Please select your total household income, before tax: </label>
			<br>
			<ul class="list-group">
				<li class="list-group-item" >$0 to $19,999 <span class="pull-right"><input type="radio" name="question12" value="1" ></span></li>
				<li class="list-group-item">$20,000 to $39,999 <span class="pull-right"><input type="radio" name="question12" value="2" ></span></li>
				<li class="list-group-item">$40,000 to $59,999 <span class="pull-right"><input type="radio" name="question12" value="3" ></span></li>
				<li class="list-group-item">$60,000 to $79,000 <span class="pull-right"><input type="radio" name="question12" value="4" ></span></li>
				<li class="list-group-item">$80,000 to $99,999 <span class="pull-right"><input type="radio" name="question12" value="5" ></span></li>
				<li class="list-group-item">$100,000 to $119,000 <span class="pull-right"><input type="radio" name="question12" value="6" ></span></li>
				<li class="list-group-item">$120,000 or more <span class="pull-right"><input type="radio" name="question12" value="7" ></span></li>

			</ul>			
		</div>		


		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="submit" name="submit" class="submit action-button" value="Submit" />
	</fieldset>
</form>


</body>
</html>