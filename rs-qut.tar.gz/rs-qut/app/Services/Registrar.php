<?php namespace App\Services;

use App\User;
use App\Survey;
use Validator;
use Illuminate\Contracts\Auth\Registrar as RegistrarContract;

class Registrar implements RegistrarContract {

	/**
	 * Get a validator for an incoming registration request.
	 *
	 * @param  array  $data
	 * @return \Illuminate\Contracts\Validation\Validator
	 */
	public function validator(array $data)
	{
		return Validator::make($data, [
			// 'firstname' => 'required|max:255',
			// 'lastname' => 'required|max:255',
			// 'email' => 'required|email|max:255|unique:users',
			// 'password' => 'required|confirmed|min:4',
			// 'consent' => 'required|accepted',
			'loyalty_program' => 'required',
			'gender' => 'required',
			'birth_year' => 'required',
			'related_industry' => 'required',
		]);
	}

	/**
	 * Create a new user instance after a valid registration.
	 *
	 * @param  array  $data
	 * @return User
	 */
	public function create(array $data)
	{
		if ($data['birth_year'] <= 1998 && count($data['related_industry']) == 1) {//if 18+
				 
				if (in_array(4, $data['related_industry'])  || in_array(3, $data['related_industry'])) {
						$is_valid = 1;		
				}else{
				
				$is_valid = 2;
			}
			
		} else {
			$is_valid = 2;
		}
		

		// dd($data['related_industry']);

		
		$user = User::create([
			// 'firstname' => $data['firstname'],
			// 'lastname' => $data['lastname'],
			// 'email' => $data['email'],
			// 'password' => bcrypt($data['password']),
			'consent' => 1,
			'loyalty_program' => $data['loyalty_program'],
			'gender' => $data['gender'],
			'birthyear' => $data['birth_year'],
			'is_valid' => $is_valid,
			// 'related_industry' => $data['related_industry'],

		]);

		$survey = new Survey;
		$survey->user_id = $user->id;
		$survey->is_valid = $is_valid;
		$survey->question1 = $data['loyalty_program'];
		$survey->question2 = $data['gender'];
		$survey->question3 = $data['birth_year'];
		foreach ($data['related_industry'] as $key => $value) {
			
			switch ($value) {
				case 1:
					$survey->question4a = $value;
					break;
				case 2:
					$survey->question4b = $value;
					break;
				case 3:
					$survey->question4c = $value;
					break;									
				case 4:
					$survey->question4d = $value;
					break;					
				default:
					# Do Nothing
					break;
			}

		}

		$survey->save();
		return $user;

	}

}
