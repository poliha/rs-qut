<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function()
{		
	if (Auth::check()) {
		return Redirect::to('home');
	} else {
		return view('welcome');
	}
	
		
    
});

Route::get('home', 'ProductController@index');
Route::get('addToCart', 'ProductController@addToCart');
Route::get('removeCart', 'ProductController@removeCart');
Route::get('category/{category}', 'ProductController@category');
Route::get('checkout', 'ProductController@checkOut');
Route::get('timer-co', 'ProductController@timerCheckOut');


Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);

Route::get('welcome', function()
{		
		return view('welcome');
    
});

Route::get('privacy', function()
{		
		return view('privacy');
    
});

Route::get('view-cart', function()
{		
		$items = Cart::content();
		$total_price = Cart::total();
		return view('shop.cart', ['items' => $items, 'total_price' => $total_price]);
    
});

Route::get('setTimer', 'ProductController@setTimer');
Route::get('start-shopping/{lt}', 'ProductController@startShopping');
Route::get('survey-intro', 'SurveyController@index');
Route::get('start-survey', 'SurveyController@startSurvey');
Route::get('getsurburb', 'SurveyController@getSurburb');
Route::post('submit-survey', 'SurveyController@postSurvey');

Route::get('shows', function()
{		
		// $data = Session::get('time_left');
		$data = Session::get('points');
		// $data = Cart::content();

		// foreach ($data as $key => $value) {
		// 	# code...
		// 		echo $value.'<br />';
		// 	}
			 print_r($data);die;
    
});
