<?php namespace App\Http\Controllers;

use App\Survey;
use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;
use Auth;
class SurveyController extends Controller {


	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('shop.intro');
	}

	public function startSurvey()
	{
		return view('form');
	}

	public function getSurburb(Request $request)
	{
		 // Set your API key: remember to change this to your live API key in production
		$apiKey = '16ca9d4a-e5b1-43b2-b414-e53b71eea0a9';
		$query = $request->get('pcquery');
		// Set the URL for the Postcode Search service
		$urlPrefix = 'auspost.com.au';
		$pcSearchURL = 'http://' . $urlPrefix . '/api/postcode/search.json';
		$queryURL = $pcSearchURL.'?q='.$query;

		// Lookup domestic/postcode/search
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $queryURL);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('AUTH-KEY: ' . $apiKey));
		$rawBody = curl_exec($ch);

		// Check the response: if the body is empty then an error occurred
		if(!$rawBody){
		  die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
		}

		// All good, lets parse the response into a JSON object
		$pcSearchJSON = json_decode($rawBody, true);	
		// print_r($pcSearchJSON);
		// foreach ($pcSearchJSON as $key => $value) {
		// 	echo $key;
		// 	foreach ($value as $key2 => $value2) {
		// 	echo $value2;
				
		// 	}
		// }
		//  dd($rawBody);
		return $rawBody;
	}

	public function postSurvey(Request $request)
	{
		$this->validate($request,
                          [
                          	'question5a' => 'required',
                          	'question5b' => 'required',
                          	'question5c' => 'required',
                          	'question5d' => 'required',
                          	'question5e' => 'required',
                          	'question5f' => 'required',
                          	'question5g' => 'required',
                          	'question5h' => 'required',
                          	'question5i' => 'required',
                          	'question5j' => 'required',
                          	'question5k' => 'required',
                          	'question5l' => 'required',
                          	'question5m' => 'required',
                          	'question5n' => 'required',
                          	'question5o' => 'required',
                          	'question5p' => 'required',
                          	'question5q' => 'required',
                          	'question5r' => 'required',
                          	'question5s' => 'required',
                          	'question5t' => 'required',
                          	'question6a' => 'required',
                          	'question6b' => 'required',
                          	'question6c' => 'required',
                          	'question6d' => 'required',
                          	'question6e' => 'required',
                          	'question6f' => 'required',
                          	'question7a' => 'required',
                          	'question7b' => 'required',
                          	'question7c' => 'required',
                          	'question7d' => 'required',
                          	'question8a' => 'required',
                          	'question8b' => 'required',
                          	'question8c' => 'required',
                          	'question8d' => 'required',
                          	'question8e' => 'required',
                          	'question8f' => 'required',
                          	'question9a1' => 'required',
                          	'question9a2' => 'required',
                          	'question9a3' => 'required',
                          	'question9b' => 'required',
                          	'question9c' => 'required',
                          	'question9d' => 'required',
                          	'question9e' => 'required',
                          	'question9f' => 'required',
                          	'question9g' => 'required',
                          	'question10' => 'required',
                          	'question11' => 'required|numeric',
                          	'question12' => 'required',

                          ]
                      );
		$survey = Survey::where('user_id', Auth::user()->id)->first();

			$survey->question5a = $request->get('question5a');
			$survey->question5b = $request->get('question5b');
			$survey->question5c = $request->get('question5c');
			$survey->question5d = $request->get('question5d');
			$survey->question5e = $request->get('question5e');
			$survey->question5f = $request->get('question5f');
			$survey->question5g = $request->get('question5g');
			$survey->question5h = $request->get('question5h');
			$survey->question5i = $request->get('question5i');
			$survey->question5j = $request->get('question5j');
			$survey->question5k = $request->get('question5k');
			$survey->question5l = $request->get('question5l');
			$survey->question5m = $request->get('question5m');
			$survey->question5n = $request->get('question5n');
			$survey->question5o = $request->get('question5o');
			$survey->question5p = $request->get('question5p');
			$survey->question5q = $request->get('question5q');
			$survey->question5r = $request->get('question5r');
			$survey->question5s = $request->get('question5s');
			$survey->question5t = $request->get('question5t');
			$survey->question6a = $request->get('question6a');
			$survey->question6b = $request->get('question6b');
			$survey->question6c = $request->get('question6c');
			$survey->question6d = $request->get('question6d');
			$survey->question6e = $request->get('question6e');
			$survey->question6f = $request->get('question6f');
			$survey->question7a = $request->get('question7a');
			$survey->question7b = $request->get('question7b');
			$survey->question7c = $request->get('question7c');
			$survey->question7d = $request->get('question7d');
			$survey->question8a = $request->get('question8a');
			$survey->question8b = $request->get('question8b');
			$survey->question8c = $request->get('question8c');
			$survey->question8d = $request->get('question8d');
			$survey->question8e = $request->get('question8e');
			$survey->question8f = $request->get('question8f');
			$survey->question9a1 = $request->get('question9a1');
			$survey->question9a2 = $request->get('question9a2');
			$survey->question9a3 = $request->get('question9a3');
			$survey->question9b = $request->get('question9b');
			$survey->question9c = $request->get('question9c');
			$survey->question9d = $request->get('question9d');
			$survey->question9e = $request->get('question9e');
			$survey->question9f = $request->get('question9f');
			$survey->question9g = $request->get('question9g');
			$survey->question10 = $request->get('question10');
			$survey->question11 = $request->get('question11');
			$survey->question12 = $request->get('question12');

		$survey->save();

		Auth::logout();
		return view('thank-you');
	}

}
