<?php namespace App\Http\Controllers;

use App\Product;
use App\Survey;
use App\Letter;
use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;

class ProductController extends Controller {


	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index(Request $request)
	{
		$user = \Auth::user();
		if ($user->is_valid != 1) {
			return view('not-eligible');
		}

		$survey = Survey::where('user_id', $user->id)->first();

		if ($survey->shopping_letter == 0) {
			# display random letter
			#$random = mt_rand(1,4);
			
			$letters = Letter::find(4);	
			return view('shop.letter', ['letters' => $letters]);
			
		} else {
			if ($survey->shopping_complete) {
				return redirect()->to('survey-intro');
			} else {
				# display products page
				$products = Product::paginate(9);
				// TODO check if shopping complete and redirect to survey
				return view('shop.product', ['products' => $products]);
			}

		}
		
	}

	public function addToCart(Request $request)
	{
		$pid = $request->get('product_id');
		$item = Product::find($pid);
		Cart::add($pid, $item->name, 1, $item->price, array('size' => 'large'));
		if (\Session::has('points.'.$item->subcat)) {
			//do nothing
		} else {
			\Session::put('points.'.$item->subcat, $item->point);
			
		}
		
$points = 0;
		if (\Session::has('points')) {
			$data = \Session::get('points');
		
			foreach ($data as $key => $value) {
						$points += $value;
			}

		}
		if (Cart::total() >= 100) {
			// checkout
		//	 return redirect()->to('checkout');
		return [Cart::count(), Cart::total(), 'true'];
		}

		if ($points >= 500) {
			// checkout
			//return redirect()->to('checkout');
			return [Cart::count(), Cart::total(), 'true'];
		}	
	
		// $items = Cart::content();
		// $total_price = Cart::total();
		// $products = Product::all();
		// $products = null;
		// return redirect()->url('view-cart')->with('success_message', 'added');
		// return view('shop.cart', ['items' => $items, 'total_price' => $total_price]);
		return [Cart::count(), Cart::total()];
	}	

	public function removeCart(Request $request)
	{
		$rid = $request->get('row_id');
		$pid = $request->get('product_id');
		if (\Session::has('points.'.$pid)) {
			
			\Session::forget('points.'.$pid);
		} else {
			
			//do nothing
		}
		
		Cart::remove($rid);
		// $items = Cart::content();
		// $total_price = Cart::total();
		// $products = Product::all();
		// $products = null;
		// return redirect()->url('view-cart')->with('success_message', 'added');
		// return view('shop.cart', ['items' => $items, 'total_price' => $total_price]);
		return Cart::count();
	}	

	public function checkOut(Request $request)
	{
		$user = \Auth::user();
		$user->total_purchase = Cart::total();
		$user->total_time = \Session::get('time_left');
		$points = 0;
		if (\Session::has('points')) {
			$data = \Session::get('points');
		
			foreach ($data as $key => $value) {
						$points += $value;
			}

		}
		
		$time_left = \Session::get('time_left');
		$time_spent = 60 - $time_left; 

		$user->total_point = $points;
		$user->save();

		$survey = Survey::where('user_id', $user->id)->first();
		$survey->total_point = $points;
		$survey->total_time = \Session::get('time_left');
		$survey->total_purchase = Cart::total();
		$survey->timer = 1;
		$survey->shopping_complete = 1;
		$survey->save();
		$survey_url = 'http://survey.qut.edu.au/f/187293/10f1/?LQID=1&total_purchase='.Cart::total().'&total_points='.$points.'&time_spent='.$time_spent;		

		Cart::destroy();
		\Session::forget('points');
		\Session::forget('time_left');

				return redirect()->to($survey_url);

	//	return redirect()->to('survey-intro');

	}	

	public function timerCheckOut(Request $request)
	{
		$user = \Auth::user();
		$user->total_purchase = Cart::total();
		$user->total_time = \Session::get('time_left');
		$points = 0;
		if (\Session::has('points')) {
			$data = \Session::get('points');
		
			foreach ($data as $key => $value) {
						$points += $value;
			}

		}
			$time_left = \Session::get('time_left');
		$time_spent = 60 - $time_left; 	
		
		$user->total_point = $points;
		$user->save();

		$survey = Survey::where('user_id', $user->id)->first();
		$survey->total_point = $points;
		$survey->total_time = \Session::get('time_left');
		$survey->total_purchase = Cart::total();
		$survey->timer = 2;
		$survey->shopping_complete = 1;
		$survey->save();
		$survey_url = 'http://survey.qut.edu.au/f/187293/10f1/?LQID=1&total_purchase='.Cart::total().'&total_points='.$points.'&time_spent='.$time_spent;;
		
		Cart::destroy();
		\Session::forget('points');
				return redirect()->to($survey_url);

		//return redirect()->to('survey-intro');

	}	



	public function setTimer(Request $request)
	{
		$time = $request->get('time');
		\Session::forget('time_left');
		\Session::put('time_left', $time);
	}


	public function startShopping($lt = null)
	{
		$user = \Auth::user();
		if (!is_null($lt)) {
			if (is_numeric($lt)) {
				$survey = Survey::where('user_id', $user->id)->first();
				$survey->shopping_letter = $lt;
				$survey->save();
			}
		}

		return redirect()->to('/');

	}

	public function category($category = null)
	{
		if (is_null($category)) {
			return redirect()->to('/');
		} else {
				
			$user = \Auth::user();
			$survey = Survey::where('user_id', $user->id)->first();

			if ($survey->shopping_letter == 0) {
				# display random letter
				$random = mt_rand(1,4);

				$letters = Letter::find($random);	
				return view('shop.letter', ['letters' => $letters]);
				
			} else {
				if ($survey->shopping_complete) {
					return redirect()->to('survey-intro');
				} else {
					# display products page
					$products = Product::where('category', $category)->paginate(5);
					return view('shop.product', ['products' => $products]);
				}

			}
			
		}
		
		
	}

}
