<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSurveysTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('surveys', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('is_valid');
			$table->integer('total_time');
			$table->integer('total_purchase');
			$table->integer('total_point');
			$table->integer('question1');
			$table->integer('question2');
			$table->integer('question3');
			$table->integer('question4a');
			$table->integer('question4b');
			$table->integer('question4c');
			$table->integer('question4d');
			$table->integer('question5a');
			$table->integer('question5b');
			$table->integer('question5c');
			$table->integer('question5d');
			$table->integer('question5e');
			$table->integer('question5f');
			$table->integer('question5g');
			$table->integer('question5h');
			$table->integer('question5i');
			$table->integer('question5j');
			$table->integer('question5k');
			$table->integer('question5l');
			$table->integer('question5m');
			$table->integer('question5n');
			$table->integer('question5o');
			$table->integer('question5p');
			$table->integer('question5q');
			$table->integer('question5r');
			$table->integer('question5s');
			$table->integer('question5t');
			$table->integer('question6a');
			$table->integer('question6b');
			$table->integer('question6c');
			$table->integer('question6d');
			$table->integer('question6e');
			$table->integer('question6f');
			$table->integer('question7a');
			$table->integer('question7b');
			$table->integer('question7c');
			$table->integer('question7d');
			$table->integer('question8a');
			$table->integer('question8b');
			$table->integer('question8c');
			$table->integer('question8d');
			$table->integer('question8e');
			$table->integer('question8f');
			$table->integer('question9a1');
			$table->integer('question9a2');
			$table->integer('question9a3');
			$table->integer('question9b');
			$table->integer('question9c');
			$table->integer('question9d');
			$table->integer('question9e');
			$table->integer('question9f');
			$table->integer('question9g');
			$table->integer('question10');
			$table->integer('question11');
			$table->integer('question12');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('surveys');
	}

}
